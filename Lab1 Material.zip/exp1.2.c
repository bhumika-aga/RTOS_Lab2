#include<stdio.h> 
#include<stdlib.h> 
#include<conio.h>
#include<time.h>
void delay(int sec)
{
	int mili=1000*sec;
	clock_t start =clock();
	while(clock() < start + mili)
	;
}
int main(void) 
{ 
	
    for(int i = 0; i<5; i++)
	{
    	delay(1);
        printf("%d", rand());
        if(kbhit())
        {
        	system("cls");
            printf("reset by pressing key\n");
            for(int j = 0; j<5; j++)
				{
			    	delay(1);
			        printf("%d", rand());
			        }
			    }
		}
    getch();
    return 0;

}